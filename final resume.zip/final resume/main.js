 let menu = document.querySelector(".menu-icon");
 


 menu.onclick = () => {
    
    menu.classList.toggle("move");
 };
 // Email JS
 function validate() {
    let name = document.querySelector(".name");
    let email = document.querySelector(".email");
    let msg = document.querySelector(".message");
    let sendBtn = document.querySelector(".send-btn");

    sendBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (name.value == "" || email.value == "" || msg.value == ""){
            emptyerror();
        } else {
            sendmail(name.value, email.value, msg.value);
            success();
        }
    });

}
validate();

function sendmail(name,email,msg){
    emailjs.send("service_zaxegr6","template_4dqpci7",{
        to_name: email,
        from_name: name,
        message: msg,
        });
}
function emptyerror() {
    swal({
        title: "oh No....",
        text: "Fields cannot be empty!",
        icon: "error",
         
     });
 }
 function success() {
    swal({
        title: "Email sent successfully",
        text: "We try to reply in 24 hours",
        icon: "success",
         
     });
 }